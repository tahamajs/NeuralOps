import subprocess
import sys

# لیست رتبه‌هایی که می‌خواهید تست کنید
RANKS = [32, 48, 64, 96, 128]

def run():
    for r in RANKS:
        # نام‌گذاری استاندارد برای سازگاری با اسکریپت ارزیابی
        onnx_path = f"soa_bert_rank_{r}.onnx"
        
        print(f"\n{'='*40}")
        print(f"Processing Rank: {r}")
        print(f"{'='*40}")

        # 1. تبدیل به ONNX
        try:
            subprocess.run(
                ["python", "-m", "soa.export_onnx", "--rank", str(r), "--onnx_path", onnx_path],
                check=True  # اگر خطا داد، دستور متوقف می‌شود
            )
            print(f"✅ ONNX exported: {onnx_path}")
        except subprocess.CalledProcessError as e:
            print(f"❌ Failed to export ONNX for rank {r}: {e}")
            continue # ادامه به رتبه بعدی

        # 2. تبدیل به CoreML (اختیاری - با مدیریت خطا)
        ml_path = f"soa_bert_rank_{r}.mlmodel"
        try:
            subprocess.run(
                ["python", "-m", "soa.export_coreml", "--onnx_path", onnx_path, "--mlmodel_path", ml_path],
                check=True
            )
            print(f"✅ CoreML exported: {ml_path}")
        except subprocess.CalledProcessError:
            print(f"⚠️ CoreML export failed for rank {r} (This is expected if coremltools is not configured correctly). Skipping.")
        except FileNotFoundError:
            print(f"⚠️ Module 'soa.export_coreml' not found or disabled. Skipping.")

if __name__ == "__main__":
    print("🚀 Starting Rank Sweep Process...")
    run()
    print("\n🏁 Rank Sweep Process Completed.")