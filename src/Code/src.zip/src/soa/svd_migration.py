import torch
from transformers import BertModel
import numpy as np
from .config import SOAConfig
import torch.nn as nn

import torch
from transformers import BertModel
import numpy as np
from .config import SOAConfig
import torch
from transformers import BertModel
from .config import SOAConfig

def compute_global_basis_from_bert(bert: BertModel, k: int):
    """
    Computes the global basis matrix of shape [hidden_size, k].
    Returns: basis (tensor), rank (int)
    """
    print(f"🔄 Extracting QKV weights from {len(bert.encoder.layer)} layers...")
    
    q_weights = []
    k_weights = []
    v_weights = []
    
    for layer in bert.encoder.layer:
        q_weights.append(layer.attention.self.query.weight.detach().cpu())
        k_weights.append(layer.attention.self.key.weight.detach().cpu())
        v_weights.append(layer.attention.self.value.weight.detach().cpu())
        
    W_q = torch.cat(q_weights, dim=0)
    W_k = torch.cat(k_weights, dim=0)
    W_v = torch.cat(v_weights, dim=0)
    
    W_combined = torch.cat([W_q, W_k, W_v], dim=0) # Shape: [27648, 768]
    
    U, S, Vh = torch.linalg.svd(W_combined, full_matrices=False)
    # Vh shape: [768, 768]
    
    # برداشت r اولین سطرهای Vh (که همان بردارهای اصلی هستند)
    # Vh[:k] شکل [768, k] دارد.
    # اگر خروجی شما [64, 768] بود، یعنی احتمالا از .T استفاده کرده‌اید یا ترتیب را اشتباه گرفته‌اید.
    # اینجا مستقیماً از Vh[:k] استفاده می‌کنیم که باید [768, 64] باشد.
    
    basis = Vh[:k] 
    
    # چک نهایی: اگر شکل غلط بود، آن را اصلاح کن (برای اطمینان)
    if basis.shape != (768, k):
        print(f"⚠️ Warning: Unexpected basis shape {basis.shape}. Transposing to match expected shape (768, {k})...")
        basis = basis.T
        
    print(f"✅ Basis computed with final shape: {basis.shape}")
    return basis, k


def migrate_bert_to_soa(bert: BertModel, soa_model, basis):
    """
    Initialize SOA model from BERT using the global basis.
    """
    expected_h = soa_model.cfg.hidden_size
    expected_r = soa_model.cfg.k_rank
    
    print(f"🔍 Checking dimensions...")
    print(f"  Expected Basis Shape: ({expected_h}, {expected_r})")
    print(f"  Actual Basis Shape: {basis.shape}")
    
    # بررسی صریح ابعاد
    if basis.shape != (expected_h, expected_r):
        raise RuntimeError(
            f"Shape mismatch! "
            f"Expected ({expected_h}, {expected_r}), "
            f"got {basis.shape}. "
            f"Check config or computation."
        )

    # 1. Embeddings
    soa_model.word_emb.weight.data.copy_(bert.embeddings.word_embeddings.weight.data)
    soa_model.pos_emb.weight.data.copy_(bert.embeddings.position_embeddings.weight.data)
    soa_model.seg_emb.weight.data.copy_(bert.embeddings.token_type_embeddings.weight.data)
    soa_model.ln.weight.data.copy_(bert.embeddings.LayerNorm.weight.data)
    soa_model.ln.bias.data.copy_(bert.embeddings.LayerNorm.bias.data)

    # 2. Copy Basis
    # توجه: در مدل شما `x_latent = h @ self.basis`.
    # اگر `h` شکل (B, S, H) و `basis` شکل (H, R) باشد، نتیجه (B, S, R) است.
    # بنابراین `basis` باید مستقیماً به شکل (768, 64) باشد و نیازی به `.T` نیست.
    soa_model.basis.data.copy_(basis) 

    # 3. Pooler & Classifier
    if hasattr(soa_model, 'pooler') and bert.pooler is not None:
        soa_model.pooler.weight.data.copy_(bert.pooler.dense.weight.data)
        soa_model.pooler.bias.data.copy_(bert.pooler.dense.bias.data)
        
    if hasattr(soa_model, 'cls'):
        if soa_model.cls.in_features == bert.pooler.out_features:
             soa_model.cls.weight.data.copy_(bert.pooler.dense.weight.data)
             soa_model.cls.bias.data.copy_(bert.pooler.dense.bias.data)
        else:
            print(f"⚠️ Warning: Classifier dimension mismatch ({soa_model.cls.in_features} vs {bert.pooler.out_features}). Weights remain random.")

    # 4. Encoder Layers
    for i, (soa_layer, bert_layer) in enumerate(zip(soa_model.layers, bert.encoder.layer)):
        soa_layer.ln1.weight.data.copy_(bert_layer.layernorm_before_attention.weight.data)
        soa_layer.ln1.bias.data.copy_(bert_layer.layernorm_before_attention.bias.data)
        
        soa_layer.ln2.weight.data.copy_(bert_layer.layernorm_after_attention.weight.data)
        soa_layer.ln2.bias.data.copy_(bert_layer.layernorm_after_attention.bias.data)
        
        soa_layer.ffn[0].weight.data.copy_(bert_layer.intermediate.dense.weight.data)
        soa_layer.ffn[0].bias.data.copy_(bert_layer.intermediate.dense.bias.data)
        soa_layer.ffn[2].weight.data.copy_(bert_layer.output.dense.weight.data)
        soa_layer.ffn[2].bias.data.copy_(bert_layer.output.dense.bias.data)

    print("✅ Migration completed successfully!")
    return soa_model


def migrate_bert_to_soa(bert: BertModel, soa_model, basis):
    """
    Initialize SOA model from BERT using the global basis.
    """
    print(f"🔍 Debugging shapes...")
    print(f"  SOA hidden_size: {soa_model.cfg.hidden_size}")
    print(f"  SOA k_rank: {soa_model.cfg.k_rank}")
    print(f"  Basis shape from function: {basis.shape}")
    
    # 1. Embeddings
    soa_model.word_emb.weight.data.copy_(bert.embeddings.word_embeddings.weight.data)
    soa_model.pos_emb.weight.data.copy_(bert.embeddings.position_embeddings.weight.data)
    soa_model.seg_emb.weight.data.copy_(bert.embeddings.token_type_embeddings.weight.data)
    soa_model.ln.weight.data.copy_(bert.embeddings.LayerNorm.weight.data)
    soa_model.ln.bias.data.copy_(bert.embeddings.LayerNorm.bias.data)

    # 2. تنظیم Basis
    expected_shape = (soa_model.cfg.hidden_size, soa_model.cfg.k_rank)
    actual_shape = basis.shape
    
    print(f"  Expected basis shape: {expected_shape}")
    
    # بررسی و اصلاح ابعاد
    if actual_shape[0] != expected_shape[0]:
        raise RuntimeError(f"Hidden size mismatch: Model expects {expected_shape[0]}, got {actual_shape[0]}")
    
    if actual_shape[1] != expected_shape[1]:
        print(f"⚠️ Rank mismatch: Expected {expected_shape[1]}, got {actual_shape[1]}. Adjusting...")
        if actual_shape[1] > expected_shape[1]:
            basis = basis[:, :expected_shape[1]]
        else:
            # Padding with zeros
            new_basis = torch.zeros(expected_shape, dtype=basis.dtype)
            new_basis[:, :actual_shape[1]] = basis
            basis = new_basis
            
    print(f"  Final basis shape: {basis.shape}")
    
    # کپی کردن بیس
    # توجه: در مدل شما self.basis یک Parameter است با شکل [hidden_size, k_rank]
    # و basis ما هم همین شکل را دارد. پس نیازی به T نیست مگر اینکه منطق داخلی متفاوت باشد.
    # در کد SOABlock شما: x_latent = h @ self.basis -> (B,S,H) @ (H,R) -> (B,S,R)
    # پس شکل باید [H, R] باشد.
    
    soa_model.basis.data.copy_(basis)

    # 3. Pooler & Classifier
    # 3. Pooler & Classifier
    if hasattr(soa_model, 'pooler') and bert.pooler is not None:
        soa_model.pooler.weight.data.copy_(bert.pooler.dense.weight.data)
        soa_model.pooler.bias.data.copy_(bert.pooler.dense.bias.data)
        
    if hasattr(soa_model, 'cls'):
        # نکته مهم: ما نمی‌توانیم وزن‌های pooler (768x768) را در cls (768x2) کپی کنیم.
        # بنابراین، وزن‌های cls را رندوم نگه می‌داریم و فقط pooler را کپی می‌کنیم.
        print(f"⚠️ Note: Skipping weight copy for 'cls' layer due to dimension mismatch (BERT pooler is {bert.pooler.dense.weight.shape[1]}x{bert.pooler.dense.weight.shape[0]}, but SOA cls is {soa_model.cls.in_features}x{soa_model.cls.out_features}).")
        print("   The classifier weights will remain random and need training.")


    # 4. Encoder Layers
    # 4. Encoder Layers
    # 4. Encoder Layers
    for i, (soa_layer, bert_layer) in enumerate(zip(soa_model.layers, bert.encoder.layer)):
        print(f"   Processing layer {i+1}...")
        
        # --- یافتن LayerNormها به صورت پویا ---
        # ما به دنبال تمام لایه‌های LayerNorm در این لایه هستیم
        layer_norms = [m for m in bert_layer.modules() if isinstance(m, nn.LayerNorm)]
        
        if len(layer_norms) < 2:
            raise RuntimeError(f"Could not find exactly 2 LayerNorm layers in BertLayer at index {i}. Found: {len(layer_norms)}")
            
        # فرض بر این است که ترتیب آنها در لیست modules به ترتیب ظهور در کد است
        # اما برای اطمینان بیشتر، معمولا اولی مربوط به attention و دومی به output است
        ln_before_attn = layer_norms[0]
        ln_after_attn = layer_norms[1]

        # کپی وزن‌های LayerNorm 1 (قبل از Attention)
        soa_layer.ln1.weight.data.copy_(ln_before_attn.weight.data)
        soa_layer.ln1.bias.data.copy_(ln_before_attn.bias.data)
        
        # کپی وزن‌های LayerNorm 2 (بعد از Attention)
        soa_layer.ln2.weight.data.copy_(ln_after_attn.weight.data)
        soa_layer.ln2.bias.data.copy_(ln_after_attn.bias.data)
        
        # کپی وزن‌های FFN (Feed Forward Network)
        # این بخش معمولاً ثابت است: intermediate -> output
        soa_layer.ffn[0].weight.data.copy_(bert_layer.intermediate.dense.weight.data)
        soa_layer.ffn[0].bias.data.copy_(bert_layer.intermediate.dense.bias.data)
        soa_layer.ffn[2].weight.data.copy_(bert_layer.output.dense.weight.data)
        soa_layer.ffn[2].bias.data.copy_(bert_layer.output.dense.bias.data)
    print("✅ Migration completed successfully!")
    return soa_model



# تابع کمکی برای اجرای مستقل
def init_from_bert(bert_name="bert-base-uncased", r=64, out_path="soa_init.pt"):
    bert = BertModel.from_pretrained(bert_name)
    basis, _ = compute_global_basis_from_bert(bert, k=r)
    torch.save({"basis": basis}, out_path)
    print(f"Saved basis to {out_path}")