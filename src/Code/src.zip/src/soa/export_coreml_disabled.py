import coremltools as ct
import onnx

def export_coreml(onnx_path="soa_bert.onnx", mlmodel_path="soa_bert.mlmodel"):
    # بارگذاری مدل ONNX
    try:
        onnx_model = onnx.load(onnx_path)
    except FileNotFoundError:
        print(f"❌ فایل ONNX یافت نشد: {onnx_path}")
        return

    print("⏳ در حال تبدیل ONNX به CoreML...")
    
    try:
        # تبدیل با استفاده از روش جدید در coremltools 6.x+
        # توجه: compute_units ممکن است نیاز به بررسی داشته باشد اگر NE پشتیبانی نشود
        mlmodel = ct.convert(
            onnx_model,
            inputs=[
                ct.TensorType(name="input_ids", shape=(1, 128)),
                ct.TensorType(name="token_type_ids", shape=(1, 128)),
                ct.TensorType(name="attention_mask", shape=(1, 128))
            ],
            convert_to="mlprogram",
            minimum_deployment_target=ct.target.iOS16,
            # حذف compute_units یا تنظیم آن به CPU_AND_GPU برای اطمینان بیشتر
            # اگر خطا داد، این خط را کامنت کنید
            # compute_units=ct.ComputeUnit.CPU_AND_NEURAL_ENGINE 
        )
        
        mlmodel.save(mlmodel_path)
        print(f"✅ مدل CoreML با موفقیت ذخیره شد: {mlmodel_path}")
        
    except Exception as e:
        print(f"❌ خطا در تبدیل CoreML: {e}")
        print("💡 نکته: اگر دستگاه شما Neural Engine ندارد، ممکن است نیاز به تنظیم compute_units به CPU باشد.")

if __name__ == "__main__":
    export_coreml()